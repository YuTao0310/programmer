import time

def main():
    for remaining in range(5, 0, -1):
	    print('Remaining: ', remaining) 

if __name__ == '__main__':
    main()
