isis2json.py
============

This directory contains a copy of the ``isis2json.py`` script, with
minimal dependencies, just to allow the O'Reilly Atlas toolchain to
render the listing of the script in appendix A of the book.

If you want to use or contribute to this script, please get the full
source code with all dependencies from the main ``isis2json``
repository:

https://github.com/fluentpython/isis2json
